# -*- coding: utf-8 -*-
"""
Created on Sun May 16 15:04:26 2021

@author: leoma
"""

#Programme principale

from random import *
from tkinter import *
from emailSend import *
from PIL import ImageTk,Image
from basedonne import *
def page1(mail) :
    application=Tk()
    pixelVirtual =PhotoImage(width=1, height=1)
    application.title("Application")
    application.geometry("1280x720")
    application.config(background="#42424D")
    back =Image.open("back2.jpg")
    application.iconbitmap('dollard.ico')
    
    background_image=ImageTk.PhotoImage(back)
    imgback = Label(application,image=background_image)
    imgback.place(x=0,y=0)
    
    
    
    menuu = Canvas(application, width=1010, height=670,bg="white")
    menuu.place(x=250,y=20)
    

    
    if verification(mail) == True :
        menuu.create_text(160,250,text="Ancienne ip de connexion ",font=("Courrier",15),fill="black")
        menuu.create_text(550,250,text="Date de la dernière connexion ",font=("Courrier",15),fill="black")
        menuu.create_text(160,420,text="Nombre de connexion ",font=("Courrier",15),fill="black")
        lastip=lastIP_get(mail)
        date_co = date_get(mail)
        nbconnexion=nbconnect_get(mail)
        menuu.create_text(150,300,text=lastip,font=("Courrier",15),fill="black")
        menuu.create_text(550,300,text=date_co,font=("Courrier",15),fill="black")
        menuu.create_text(150,470,text=str(nbconnexion),font=("Courrier",15),fill="black")
    
    name=nom_get(mail)
    prename=prenom_get(mail)
    nom=name+"               "+prename

    image_profil=image_get(mail)
        
    menuu.create_text(300,50,text=nom,font=("Courrier",40),fill="black")
    
    
    menuu.create_text(360,150,text="Adresse Email : "+mail,font=("Courrier",28),fill="black")
    
    
    
    changeMDP=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer de mot de passe",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    changeMDP.place(x=300,y=380)
    
    changeMAIL=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer d'adresse Email",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    changeMAIL.place(x=700,y=380)

    changeName=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer de Nom",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    changeName.place(x=300,y=480)
    
    changePrename=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer de Prénom",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    changePrename.place(x=700,y=480)
    
    delete=Button(menuu,font=("Courrier",15),fg="black",bg='#E84C3D',text="Supprimer le compte",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    delete.place(x=500,y=570)    
    
    profil_canvas = Canvas(application, width=250, height=250,bg="#595959",borderwidth=10,relief="sunken")
    profil_canvas.place(x=980,y=30)

    importI=Button(menuu,font=("Courrier",10),fg="black",bg='#595959',text="importer une image ",width=20,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    importI.place(x=785,y=290)
    application.mainloop()
    
page1("leo52.mans@gmail.com")