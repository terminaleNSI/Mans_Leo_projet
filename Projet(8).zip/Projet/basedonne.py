# -*- coding: utf-8 -*-
"""
Created on Mon May 10 09:35:35 2021

@author: leoma
"""

import sqlite3
import hashlib
from time import strftime
from socket import *

def compte_bdd(name:str,prename:str,mail:str,mdp:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS IDENTIFIANTS(id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, name TEXT, prename TXT, adresse TXT, MDP TXT, image BLOB, nbconnect INT,lastIP TEXT,date TEXT)")
    conn.commit()
    info=[name,prename,mail,str.encode(mdp),None,0,"",""]
    m = hashlib.sha256()
    m.update(info[3])
    info[3]=(str(m.digest()))
    cur.execute("INSERT INTO IDENTIFIANTS(name,prename,adresse,MDP,image,nbconnect,lastIP,date) VALUES(?,?,?,?,?,?,?,?)",info);
    conn.commit();
    cur.close()
    conn.close()

def connexion_bdd(mail:str,mdp:str) :
    # 0 = mail introuvable
    # 1 = mdp introuvable
    # 3 = connecting
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT adresse FROM IDENTIFIANTS')
    lst_mail = cur.fetchall()
    #print(lst_mail)
    recherche=(mail,)
    #print(recherche)
    for e in lst_mail :
        mailverif=e[0]
        if mailverif == mail :
            cur.execute('SELECT mdp FROM IDENTIFIANTS WHERE adresse = ? ', recherche)
            m = hashlib.sha256()
            motdepassse = cur.fetchall()
            m.update(str.encode(mdp))
            mdp= m.digest()
            if motdepassse[0][0] == str(mdp):
                return 3
            else:
                return 1
    
    return 0
def nom_get(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT name FROM IDENTIFIANTS WHERE adresse = ? ', (mail,))
    lst_nom = cur.fetchall()
    cur.close()
    conn.close() 
    return lst_nom[0][0]
def prenom_get(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT prename FROM IDENTIFIANTS WHERE adresse = ? ', (mail,))
    lst_prenom = cur.fetchall()
    cur.close()
    conn.close() 
    return lst_prenom[0][0]  
def image_get(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT image FROM IDENTIFIANTS WHERE adresse = ? ', (mail,))
    lst_img = cur.fetchall()
    cur.close()
    conn.close() 
    return lst_img[0][0] 
def date_get(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT date FROM IDENTIFIANTS WHERE adresse = ? ', (mail,))
    lst_date = cur.fetchall()
    cur.close()
    conn.close() 
    return lst_date[0][0] 
def nbconnect_get(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT nbconnect FROM IDENTIFIANTS WHERE adresse = ? ', (mail,))
    lst_nbconnect = cur.fetchall()
    cur.close()
    conn.close() 
    return lst_nbconnect[0][0] 
def lastIP_get(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute('SELECT lastIP FROM IDENTIFIANTS WHERE adresse = ? ', (mail,))
    lst_lastIP = cur.fetchall()
    cur.close()
    conn.close() 
    return lst_lastIP[0][0] 
def verification(mail:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()    
    cur.execute('SELECT nbconnect FROM IDENTIFIANTS WHERE adresse = ? ',(mail,))
    nbconnect = cur.fetchall()[0][0]
    print(nbconnect)
    if nbconnect < 1:
        nbconnect=nbconnect+1
        cur.execute('UPDATE IDENTIFIANTS SET nbconnect = ? WHERE adresse = ?', (nbconnect,mail))
        conn.commit();
        print("a")
        return False
    else :
        ancienne_ip = gethostbyname(gethostname())
        time = strftime("%Y-%m-%d")
        nbconnect=nbconnect+1
        cur.execute('UPDATE IDENTIFIANTS SET nbconnect = ? WHERE adresse = ?', (nbconnect,mail))
        cur.execute('UPDATE IDENTIFIANTS SET lastIP = ? WHERE adresse = ?', (ancienne_ip,mail))
        cur.execute('UPDATE IDENTIFIANTS SET Date = ? WHERE adresse = ?', (time,mail))
        conn.commit();
        cur.close()
        conn.close()
        print("b")
        return True
    
    
    
    
    
