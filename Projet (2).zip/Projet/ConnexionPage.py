# -*- coding: utf-8 -*-
"""
Created on Thu Apr 22 11:17:32 2021

@author: leoma
"""

from tkinter import *
from PIL import ImageTk,Image
def clique(event):
    print("x= "+str(event.x)+"y= "+str(event.y))
    if event.x<=328 and event.x>=133 and event.y<=340 and event.y>=323 :
        new_account()
        
def new_account() :
    print("new")
    fenetre_creCompte=Toplevel(fenetre_base)
    fenetre_creCompte.geometry("460x600")
    fenetre_creCompte.config(background="white")
    fenetre_creCompte.title("Création de compte")
    titre_fen = Label(fenetre_creCompte,text="Création de compte",font=("Courrier",25),bg="white")
    titre_fen.place(x=92,y=30)
    
    name_fen = Label(fenetre_creCompte,text="Nom :",font=("Courrier",15),bg="white")
    name_fen.place(x=20,y=110)
    name_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white")
    name_e.place(x=20,y=135)
    
    prename_fen = Label(fenetre_creCompte,text="Prénom :",font=("Courrier",15),bg="white")
    prename_fen.place(x=20,y=190)
    prename_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white")
    prename_e.place(x=20,y=220)
    
    prename_fen = Label(fenetre_creCompte,text="Adresse Email :",font=("Courrier",15),bg="white")
    prename_fen.place(x=20,y=270)
    mail_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white")
    mail_e.place(x=20,y=300)
    
    prename_fen = Label(fenetre_creCompte,text="Mot de passe :",font=("Courrier",15),bg="white")
    prename_fen.place(x=20,y=350)
    mail_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",show="*")
    mail_e.place(x=20,y=380)
    
    prename_fen = Label(fenetre_creCompte,text="Confirmation mot de passe :",font=("Courrier",15),bg="white")
    prename_fen.place(x=17,y=430)
    mail_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",show="*")
    mail_e.place(x=20,y=460)
    
    register_but=Button(fenetre_creCompte,font=("Courrier",10),fg="BLACK",bg='grey',text="Créer le compte",width=20,height=1,activebackground="green",activeforeground="white",command=verifMail())
    register_but.place(x=64,y=520)
    
def verifMail():
    print('verif')
    
    
    
    
fenetre_base=Tk()
fenetre_base.resizable(width=False, height=False)

pixelVirtual =PhotoImage(width=1, height=1)
fenetre_base.title("Page de connexion")
fenetre_base.geometry("900x600")
fenetre_base.config(background="#42424D")
back =Image.open("back4.png")
background_image=ImageTk.PhotoImage(back)
imgback = Label(fenetre_base,image=background_image)
imgback.place(x=0,y=0)

menuu = Canvas(fenetre_base, width=460, height=350,bg="white")
menuu.place(x=220,y=100)
menuu.create_text(230,30,text="Se connecter",font=("Courrier",25))

menuu.create_text(133,100,text="Identifiants :",font=("Courrier",15))
identifiants = Entry(fenetre_base,bg="#4B4B57",font=("Courrier",20),fg="white")
identifiants.place(x=300,y=210)

menuu.create_text(145,190,text="Mot de passe :",font=("Courrier",15))
MDP = Entry(fenetre_base,bg="#4B4B57",font=("Courrier",20),fg="white",show="*")
MDP.place(x=300,y=300)

login_but=Button(menuu,font=("Courrier",10),fg="BLACK",bg='red',text="Se connecter",width=20,height=1,activebackground="black",activeforeground="white" )
login_but.place(x=140,y=270)

menuu.create_text(230,330,text="pas de compte ? créer un compte",font=("Courrier",10),activefill="blue")
fenetre_base.bind("<Button-1>",clique)
fenetre_base.mainloop()