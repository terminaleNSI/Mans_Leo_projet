# -*- coding: utf-8 -*-
"""
Created on Tue May 25 09:38:04 2021

@author: leoma
"""

from ConnexionPage import  *

p_connexion()
