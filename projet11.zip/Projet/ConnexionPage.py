# -*- coding: utf-8 -*-
"""
Created on Thu Apr 22 11:17:32 2021

@author: leoma
"""
from random import *
from tkinter import *
from emailSend import *
from PIL import ImageTk,Image
from basedonne import *
from Application import *
def clique(event):
    if event.x<=328 and event.x>=133 and event.y<=340 and event.y>=323 :
        new_account()
        
def new_account() :
    print("new")
    global mail_e
    global name_e
    global prename_e
    global mdp_e
    global mdpConfirm_e
    global fenetre_creCompte
    fenetre_creCompte=Toplevel(fenetre_base)
    fenetre_creCompte.geometry("800x500")
    fenetre_creCompte.config(background="grey")
    fenetre_creCompte.title("Création de compte")
    fenetre_creCompte.iconbitmap('dollard.ico')
    imgback2 = Label(fenetre_creCompte,image=background_image)
    imgback2.place(x=0,y=0)
   
    convas2 = Canvas(fenetre_creCompte, width=600, height=400,bg="white")
    convas2.place(x=100,y=50)
    
    fenetre_creCompte.resizable(width=False, height=False)
    
    
    titre_fen = Label(fenetre_creCompte,text="Création de compte",font=("Courrier",25),bg="white")
    titre_fen.place(x=255,y=50)
    
    name_fen = Label(fenetre_creCompte,text="Nom",font=("Courrier",15),bg="white")
    name_fen.place(x=120,y=120)
    name_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",borderwidth=3)
    name_e.place(x=120,y=150)
    
    prename_fen = Label(fenetre_creCompte,text="Prénom",font=("Courrier",15),bg="white")
    prename_fen.place(x=400,y=120)
    prename_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",borderwidth=3)
    prename_e.place(x=400,y=150)
    
    prename_fen = Label(fenetre_creCompte,text="Adresse Email ",font=("Courrier",15),bg="white")
    prename_fen.place(x=310,y=200)
    mail_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",borderwidth=3,width=50)
    mail_e.place(x=120,y=230)
    
    mdp_fen = Label(fenetre_creCompte,text="Mot de passe ",font=("Courrier",15),bg="white")
    mdp_fen.place(x=120,y=300)
    mdp_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",show="*",borderwidth=3)
    mdp_e.place(x=120,y=330)
    
    mdpConfirm_fen = Label(fenetre_creCompte,text="Confirmation",font=("Courrier",15),bg="white",borderwidth=3)
    mdpConfirm_fen.place(x=400,y=300)
    mdpConfirm_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",show="*",borderwidth=3)
    mdpConfirm_e.place(x=400,y=330)
    
    register_but=Button(fenetre_creCompte,font=("Courrier",10),fg="BLACK",bg='red',text="Créer le compte",width=20,height=1,activebackground="green",activeforeground="white",command=lambda:verifcompte())
    register_but.place(x=300,y=390)
        
def verifMail():
    global fenetre_mail
    code=""
    for i in range(5):
        nbr=randint(0,100)
        code=code+str(nbr)
    Send_email2(code,mail_e.get(),name_e.get(),prename_e.get())
    fenetre_mail=Toplevel(fenetre_base)
    fenetre_mail.geometry("500x250")
    fenetre_mail.config(background="white")
    fenetre_mail.title("vérification")
    fenetre_mail.iconbitmap('dollard.ico')
    fenetre_mail.resizable(width=False, height=False)
    mail_fen = Label(fenetre_mail,text=" Veuillez rentrer ici le message que vous avez reçu :",font=("Courrier",15),bg="white")
    mail_fen.place(x=10,y=20)
    code_fen = Label(fenetre_mail,text="Code :",font=("Courrier",15),bg="white")
    code_fen.place(x=10,y=100)
    code_e = Entry(fenetre_mail,bg="#4B4B57",font=("Courrier",15),fg="white")
    code_e.place(x=150,y=100)
    code_but=Button(fenetre_mail,font=("Courrier",10),fg="BLACK",bg='red',text="Valider",width=20,height=1,activebackground="green",activeforeground="white",command=lambda:verifCode(code,code_e.get()))
    code_but.place(x=150,y=150)
def verifcompte():
    if name_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre nom")
    elif prename_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre prenom")
    elif mail_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre adresse E-mail")
    elif mdp_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre mot de passe")
    elif mdpConfirm_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez confirmer votre mot de passe")         
    elif mdp_e.get() != mdpConfirm_e.get():
        warn_supp=messagebox.showerror("ERREUR","La confirmation du mot de passe a échoué") 
    else :
        verifMail()
def verifCode(code:str,codeEntrer:str):
    print(code)
    print(codeEntrer)
    if code != codeEntrer:
        warn_supp=messagebox.showerror("ERREUR","Code Invalide")
    else:
        code_info =messagebox.showinfo("Information","Compte Validé.")
        compte_bdd(name_e.get(),prename_e.get(),mail_e.get(),mdp_e.get())
        fenetre_creCompte.destroy()
        fenetre_mail.destroy()
def connexion():
    connectionUser=connexion_bdd(identifiants_e.get(),mdpco_e.get()) 
    if connectionUser == 0 :
        warn_supp=messagebox.showerror("ERREUR","Adresse Email introuvable")
    elif connectionUser == 1 :
        warn_supp=messagebox.showerror("ERREUR","Aucun mot de passe correspond a cette adresse Email.")
    elif connectionUser == 3 :
        code_info =messagebox.showinfo("Information","Connecter !")
        maill=str(identifiants_e.get())
        fenetre_base.destroy()
        page1(maill)
        
        
def p_connexion():   
    global fenetre_base
    global identifiants_e
    global mdpco_e
    global background_image

    fenetre_base=Tk()
    fenetre_base.resizable(width=False, height=False)
    
    pixelVirtual =PhotoImage(width=1, height=1)
    fenetre_base.title("Page de connexion")
    fenetre_base.geometry("900x600")
    fenetre_base.config(background="#42424D")
    back =Image.open("back4.png")
    fenetre_base.iconbitmap('dollard.ico')
    background_image=ImageTk.PhotoImage(back)
    imgback = Label(fenetre_base,image=background_image)
    imgback.place(x=0,y=0)
    
    menuu = Canvas(fenetre_base, width=460, height=350,bg="white")
    menuu.place(x=220,y=100)
    menuu.create_text(230,30,text="Se connecter",font=("Courrier",25))
    
    menuu.create_text(133,100,text="Identifiants :",font=("Courrier",15))
    identifiants_e = Entry(fenetre_base,bg="#4B4B57",font=("Courrier",20),fg="white")
    identifiants_e.place(x=300,y=210)
    
    menuu.create_text(145,190,text="Mot de passe :",font=("Courrier",15))
    mdpco_e = Entry(fenetre_base,bg="#4B4B57",font=("Courrier",20),fg="white",show="*")
    mdpco_e.place(x=300,y=300)
    
    login_but=Button(menuu,font=("Courrier",10),fg="BLACK",bg='red',text="Se connecter",width=20,height=1,activebackground="black",activeforeground="white",command=lambda:connexion())
    login_but.place(x=140,y=270)
    
    menuu.create_text(230,330,text="pas de compte ? créer un compte",font=("Courrier",10),activefill="blue")
    fenetre_base.bind("<Button-1>",clique)
    fenetre_base.mainloop()
