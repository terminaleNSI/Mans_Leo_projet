# -*- coding: utf-8 -*-
"""
Created on Sun May 16 15:04:26 2021

@author: leoma
"""

#Programme principale

from random import *
from tkinter import *
from tkinter.filedialog import *
from emailSend import *
from PIL import ImageTk,Image
from basedonne import *
from ConnexionPage import *


def changement(app,flag:str):
    def modif_verif(flag:str,mdp:str,e1:str,e2:str):
        if verif_mdp(mdp) == True :
            print("true")
            if update_ligne(flag,e1,e2) == False:
                warn_supp=messagebox.showerror("ERREUR","Information incorrect.")

        else:
            warn_supp=messagebox.showerror("ERREUR","Mot de passe incorrect")
    fenetre_change=Toplevel(app)
    fenetre_change.geometry("700x350")
    fenetre_change.config(background="white")
    fenetre_change.title("Changement d'information")
    fenetre_change.iconbitmap('dollard.ico')
    fenetre_change.resizable(width=False, height=False)
    if flag == "nom" :
        texte1 = "Mot de passe :"
        texte2 = "Ancien nom :"
        texte3 = "Nouveau nom :"
    if flag == "prenom" :
        texte1 = "Mot de passe :"
        texte2 = "Ancien prénom :"
        texte3 = "Nouveau prénom :"
    if flag == "mail" :
        texte1 = "Mot de passe :"
        texte2 = "Ancienne adresse Email :"
        texte3 = "Nouvelle adresse Email :"
    if flag == "mdp" :
        texte1 = "Mot de passe actuel :"
        texte2 = "Ancien mot de passe :"
        texte3 = "Nouveau mot de passe :"
        
    titre_1 = Label(fenetre_change,text=texte1,font=("Courrier",20),bg="white")
    titre_1.place(x=20,y=50) 
    titre_1e = Entry(fenetre_change,bg="#4B4B57",font=("Courrier",15),fg="white",borderwidth=3,show="*")
    titre_1e.place(x=380,y=50)
    
    titre_2 = Label(fenetre_change,text=texte2,font=("Courrier",20),bg="white")
    titre_2.place(x=20,y=150)
    titre_2e = Entry(fenetre_change,bg="#4B4B57",font=("Courrier",15),fg="white",borderwidth=3)
    titre_2e.place(x=380,y=150)
    
    titre_3 = Label(fenetre_change,text=texte3,font=("Courrier",20),bg="white")
    titre_3.place(x=20,y=250)
    titre_3e = Entry(fenetre_change,bg="#4B4B57",font=("Courrier",15),fg="white",borderwidth=3)
    titre_3e.place(x=380,y=250)
    
    change_but=Button(fenetre_change,font=("Courrier",15),fg="WHITE",bg='#4B4B57',text="Appliquer les changements",width=40,height=1,activebackground="green",activeforeground="white",command=lambda:modif_verif(flag,titre_1e.get(),titre_2e.get(),titre_3e.get()))
    change_but.place(x=230,y=300)
    
    
def delete_compte(mail:str,app):
    message=messagebox.askyesnocancel("Supression du compte","Voulez vous vraiment supprimer votre compte ?",icon='warning')
    if message == True :
        delete_ligne(mail)
        app.destroy()
        
        
def page1(mail) :
    application=Tk()
    pixelVirtual =PhotoImage(width=1, height=1)
    application.title("Application")
    application.geometry("1280x720")
    application.config(background="#42424D")
    back =Image.open("back2.jpg")
    application.iconbitmap('dollard.ico')
    
    background_image=ImageTk.PhotoImage(back)
    imgback = Label(application,image=background_image)
    imgback.place(x=0,y=0)
    
    
    
    menuu = Canvas(application, width=1010, height=670,bg="white")
    menuu.place(x=250,y=20)
    

    
    if verification(mail) == True :
        menuu.create_text(160,250,text="Ancienne ip de connexion ",font=("Courrier",15),fill="black")
        menuu.create_text(550,250,text="Date de la dernière connexion ",font=("Courrier",15),fill="black")
        menuu.create_text(160,420,text="Nombre de connexion ",font=("Courrier",15),fill="black")
        lastip=lastIP_get(mail)
        date_co = date_get(mail)
        nbconnexion=nbconnect_get(mail)
        menuu.create_text(150,300,text=lastip,font=("Courrier",15),fill="black")
        menuu.create_text(550,300,text=date_co,font=("Courrier",15),fill="black")
        menuu.create_text(150,470,text=str(nbconnexion),font=("Courrier",15),fill="black")
    
    name=nom_get(mail)
    prename=prenom_get(mail)
    nom=name+"               "+prename

    image_profil=image_get(mail)
        
    menuu.create_text(300,50,text=nom,font=("Courrier",40),fill="black")
    
    
    menuu.create_text(360,150,text="Adresse Email : "+mail,font=("Courrier",28),fill="black")
    
    
    
    changeMDP=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer de mot de passe",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:changement(application,"mdp"))
    changeMDP.place(x=300,y=380)
    
    changeMAIL=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer d'adresse Email",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:changement(application,"mail"))
    changeMAIL.place(x=700,y=380)

    changeName=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer de Nom",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:changement(application,"nom"))
    changeName.place(x=300,y=480)
    
    changePrename=Button(menuu,font=("Courrier",15),fg="black",bg='#595959',text="Changer de Prénom",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:changement(application,"prenom"))
    changePrename.place(x=700,y=480)
    
    delete=Button(menuu,font=("Courrier",15),fg="black",bg='#E84C3D',text="Supprimer le compte",width=25,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:delete_compte(mail,application))
    delete.place(x=500,y=570)    
    
    profil_canvas = Canvas(application, width=250, height=250,bg="#595959",borderwidth=10,relief="sunken")
    profil_canvas.place(x=980,y=30)

    importI=Button(menuu,font=("Courrier",10),fg="black",bg='#595959',text="importer une image ",width=20,height=1,activebackground="#E84C3D",activeforeground="white",command=lambda:connexion())
    importI.place(x=785,y=290)
    application.mainloop()
