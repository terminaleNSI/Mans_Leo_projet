# -*- coding: utf-8 -*-
"""
Created on Mon May 10 09:35:35 2021

@author: leoma
"""

import sqlite3
import hashlib


def compte(name:str,prename:str,mail:str,mdp:str):
    conn = sqlite3.connect('baseDonnees.db')
    cur = conn.cursor()
    cur.execute("CREATE TABLE IF NOT EXISTS IDENTIFIANTS(id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, name TEXT, prename TXT, adresse TXT, MDP TXT)")
    conn.commit()
    info=[name,prename,mail,str.encode(mdp)]
    m = hashlib.sha256()
    m.update(info[3])
    info[3]=(str(m.digest()))
    cur.execute("INSERT INTO IDENTIFIANTS(name,prename,adresse,MDP) VALUES(?,?,?,?)",info);
    conn.commit();
    cur.close()
    conn.close()