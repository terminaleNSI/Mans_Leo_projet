# -*- coding: utf-8 -*-
"""
Created on Thu Apr 22 11:17:32 2021

@author: leoma
"""
"""
def verif1():
    curseur=fenetre1.winfo_pointerxy() 
    if curseur[0]>420 and curseur[0]<
"""
def clique(event):
    print("x= "+str(event.x)+"y= "+str(event.y))
    if event.x>340 and event.x<505 and event.y>140 and event.y<160:
        print("connect")

from tkinter import *
from PIL import ImageTk,Image
fenetre1=Tk()
fenetre1.resizable(width=False, height=False)

pixelVirtual =PhotoImage(width=1, height=1)
fenetre1.title("Page de connexion")
fenetre1.geometry("900x600")
fenetre1.config(background="#42424D")
back =Image.open("back4.png")
background_image=ImageTk.PhotoImage(back)
imgback = Label(fenetre1,image=background_image)
imgback.place(x=0,y=0)

menuu = Canvas(fenetre1, width=460, height=350,bg="white")
menuu.place(x=220,y=100)
menuu.create_text(230,30,text="Se connecter",font=("Courrier",25))
menuu.create_text(230,330,text="pas de compte ? créer un compte",font=("Courrier",10),activefill="blue")
fenetre1.bind("<Button-1>",clique)
menuu.create_text(133,100,text="Identifiants :",font=("Courrier",15))
identifiants = Entry(fenetre1,bg="#4B4B57",font=("Courrier",20),fg="white")
identifiants.place(x=300,y=210)
menuu.create_text(145,190,text="Mot de passe :",font=("Courrier",15))
MDP = Entry(fenetre1,bg="#4B4B57",font=("Courrier",20),fg="white",show="*")
MDP.place(x=300,y=300)
loginBut=Button(menuu,font=("Courrier",10),fg="BLACK",bg='red',text="Se connecter",width=20,height=1)
loginBut.place(x=140,y=270)
fenetre1.mainloop()