# -*- coding: utf-8 -*-
"""
Created on Sun May 16 15:04:26 2021

@author: leoma
"""

#Programme principale

from random import *
from tkinter import *
from emailSend import *
from PIL import ImageTk,Image
from basedonne import *

application=Tk()
pixelVirtual =PhotoImage(width=1, height=1)
application.title("Application")
application.geometry("1280x720")
application.config(background="#42424D")
back =Image.open("back4.png")
application.iconbitmap('dollard.ico')
background_image=ImageTk.PhotoImage(back)
imgback = Label(application,image=background_image)
imgback.place(x=1000,y=0)

menuu = Canvas(application, width=1180, height=720,bg="white")
menuu.place(x=100,y=0)
menuu.create_text(230,30,text="Se connecter",font=("Courrier",25))

menuu.create_text(133,100,text="Identifiants :",font=("Courrier",15))
identifiants_e = Entry(application,bg="#4B4B57",font=("Courrier",20),fg="white")
identifiants_e.place(x=300,y=210)

menuu.create_text(145,190,text="Mot de passe :",font=("Courrier",15))
mdpco_e = Entry(application,bg="#4B4B57",font=("Courrier",20),fg="white",show="*")
mdpco_e.place(x=300,y=300)

login_but=Button(menuu,font=("Courrier",10),fg="BLACK",bg='red',text="Se connecter",width=20,height=1,activebackground="black",activeforeground="white",command=lambda:connexion())
login_but.place(x=140,y=270)

menuu.create_text(230,330,text="pas de compte ? créer un compte",font=("Courrier",10),activefill="blue")

application.mainloop()