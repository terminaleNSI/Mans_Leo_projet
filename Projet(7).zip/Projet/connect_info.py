# -*- coding: utf-8 -*-
"""
Created on Sat May 15 20:44:57 2021

@author: leoma
"""
from pathlib import Path
from time import strftime
from socket import *
import sqlite3
def ifBddExist():
    fileObj=Path('ConectInfo.db')
    if fileObj.is_file() :
        print("bdd exist")
    else:
        conn = sqlite3.connect('ConectInfo.db')
        cur = conn.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS connectInfo(id INTEGER PRIMARY KEY AUTOINCREMENT UNIQUE, nbconnect INT,lastIP TEXT,Date TEXT)")
        conn.commit()
        info=(0,"","")
        cur.execute("INSERT INTO connectInfo(nbconnect,lastIP,Date) VALUES(?,?,?)",info);
        conn.commit();
        cur.close()
        conn.close()
def info():
    conn = sqlite3.connect('ConectInfo.db')
    cur = conn.cursor()    
    cur.execute('SELECT nbconnect FROM connectInfo WHERE id = ? ',(1,))
    nbconnect = cur.fetchall()[0][0]
    if nbconnect < 1:
        nbconnect=nbconnect+1
        cur.execute('UPDATE connectInfo SET nbconnect = ? WHERE id = ?', (nbconnect,1))
        return False
    else :
        ancienne_ip = gethostbyname(gethostname())
        time = strftime("%Y-%m-%d")
        nbconnect=nbconnect+1
        cur.execute('UPDATE connectInfo SET nbconnect = ? WHERE id = ?', (nbconnect,1))
        cur.execute('UPDATE connectInfo SET lastIP = ? WHERE id = ?', (ancienne_ip,1))
        cur.execute('UPDATE connectInfo SET Date = ? WHERE id = ?', (time,1))
def verificationConnexion():
        ifBddExist()
        info()
    
nbconnect=0