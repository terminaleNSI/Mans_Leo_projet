# -*- coding: utf-8 -*-
"""
Created on Tue Apr 27 11:30:30 2021

@author: leoma
"""

import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
# on rentre les renseignements pris sur le site du fournisseur
def Send_email(nombreGenerer:int,email_receiver:str):
    try:
        smtp_adress = 'smtp.gmail.com'
        smtp_port = 465
        # on rentre les informations sur notre adresse e-mail
        mot=""
        with open('avh.txt','r') as vh:
            texte = vh.read()
        cle=10
        for i in texte :
                e=ord(i)-cle
                f=chr(e)
                mot=mot+f
        oip=mot.split("P")
        
        email_adress =oip[1]
        email_password = oip[0]
        # on crée la connexion
        context = ssl.create_default_context()
        with smtplib.SMTP_SSL(smtp_adress, smtp_port, context=context) as server:
          # connexion au compte
          server.login(email_adress, email_password)
          # envoi du mail
          server.sendmail(email_adress, email_receiver,"Verification de l'adresse Mail : "+str(nombreGenerer))
        print("Mail envoyé")
    except :
        print("erreur lors de l'envois")


def Send_email2(nombreGenerer:int,email_receiver:str,name:str,prename:str):
        smtp_adress = 'smtp.gmail.com'
        smtp_port = 465
        # on rentre les informations sur notre adresse e-mail
        mot=""
        with open('avh.txt','r') as vh:
            texte = vh.read()
        cle=10
        for i in texte :
                e=ord(i)-cle
                f=chr(e)
                mot=mot+f
        oip=mot.split("P")
        
        email_adress =oip[1]
        email_password = oip[0]
        # on crée la connexion
        context = ssl.create_default_context()
        # on crée un e-mail
        message = MIMEMultipart("alternative")
        # on ajoute un sujet
        message["Subject"] = "[Vérification de l'adresse E-mail]"
        # un émetteur
        message["From"] = email_adress
        # un destinataire
        message["To"] = email_receiver
    
       
     
        # on crée un texte et sa version HTML
        texte = '''
        Bonjour 
        Ma super newsletter
        Cdt
        mon_lien_incroyable
        '''
        html ='<html><body style="background-color:#77797C;"><h1>Mail générer automatiquement voici le code de vérification</h1><p>'+str(nombreGenerer)+'Ma super newsletter</p><b>Cdt</b><br><a href="https://datascientest.com">mon_lien_incroyable</a></body></html>'
        html2 = '<html><body style="background-color:#F5F5F5;"><p><center><font size="4">Bonjour '+name+" "+prename+" Merci d'avoir créer un compte ! pour confirmer la création de compte vous devez recopier le code si dessous :</center</font></p><br>"+'<h1 style="color:#FF0000"><center>'+str(nombreGenerer)+' </center></h1></body></html>'
        # on crée deux éléments MIMEText 
        texte_mime = MIMEText(texte, 'plain')
        html_mime = MIMEText(html2, 'html')
        
        # on attache ces deux éléments 
        message.attach(texte_mime)
        message.attach(html_mime)
        
        with smtplib.SMTP_SSL(smtp_adress, smtp_port, context=context) as server:
          # connexion au compte
          server.login(email_adress, email_password)
          # envoi du mail
          server.sendmail(email_adress, email_receiver, message.as_string())
        print("message envoyer")
