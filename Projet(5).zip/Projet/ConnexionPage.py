# -*- coding: utf-8 -*-
"""
Created on Thu Apr 22 11:17:32 2021

@author: leoma
"""
from random import *
from tkinter import *
from emailSend import *
from PIL import ImageTk,Image
from basedonne import *
def clique(event):
    if event.x<=328 and event.x>=133 and event.y<=340 and event.y>=323 :
        new_account()
        
def new_account() :
    print("new")
    global mail_e
    global name_e
    global prename_e
    global mdp_e
    global mdpConfirm_e
    global fenetre_creCompte
    fenetre_creCompte=Toplevel(fenetre_base)
    fenetre_creCompte.geometry("460x600")
    fenetre_creCompte.config(background="white")
    fenetre_creCompte.title("Création de compte")
    titre_fen = Label(fenetre_creCompte,text="Création de compte",font=("Courrier",25),bg="white")
    titre_fen.place(x=92,y=30)
    
    name_fen = Label(fenetre_creCompte,text="Nom :",font=("Courrier",15),bg="white")
    name_fen.place(x=20,y=110)
    name_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white")
    name_e.place(x=20,y=135)
    
    prename_fen = Label(fenetre_creCompte,text="Prénom :",font=("Courrier",15),bg="white")
    prename_fen.place(x=20,y=190)
    prename_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white")
    prename_e.place(x=20,y=220)
    
    prename_fen = Label(fenetre_creCompte,text="Adresse Email :",font=("Courrier",15),bg="white")
    prename_fen.place(x=20,y=270)
    mail_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white")
    mail_e.place(x=20,y=300)
    
    mdp_fen = Label(fenetre_creCompte,text="Mot de passe :",font=("Courrier",15),bg="white")
    mdp_fen.place(x=20,y=350)
    mdp_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",show="*")
    mdp_e.place(x=20,y=380)
    
    mdpConfirm_fen = Label(fenetre_creCompte,text="Confirmation mot de passe :",font=("Courrier",15),bg="white")
    mdpConfirm_fen.place(x=17,y=430)
    mdpConfirm_e = Entry(fenetre_creCompte,bg="#4B4B57",font=("Courrier",15),fg="white",show="*")
    mdpConfirm_e.place(x=20,y=460)
    
    register_but=Button(fenetre_creCompte,font=("Courrier",10),fg="BLACK",bg='grey',text="Créer le compte",width=20,height=1,activebackground="green",activeforeground="white",command=lambda:verifcompte())
    register_but.place(x=64,y=520)
        
def verifMail():
    global fenetre_mail
    code=""
    for i in range(5):
        nbr=randint(0,100)
        code=code+str(nbr)
    Send_email2(code,mail_e.get(),name_e.get(),prename_e.get())
    fenetre_mail=Toplevel(fenetre_base)
    fenetre_mail.geometry("500x250")
    fenetre_mail.config(background="white")
    fenetre_mail.title("vérification")
    mail_fen = Label(fenetre_mail,text=" Veuillez rentrer ici le message que vous avez reçu :",font=("Courrier",15),bg="white")
    mail_fen.place(x=10,y=20)
    code_fen = Label(fenetre_mail,text="Code :",font=("Courrier",15),bg="white")
    code_fen.place(x=10,y=100)
    code_e = Entry(fenetre_mail,bg="#4B4B57",font=("Courrier",15),fg="white")
    code_e.place(x=150,y=100)
    code_but=Button(fenetre_mail,font=("Courrier",10),fg="BLACK",bg='grey',text="Valider",width=20,height=1,activebackground="green",activeforeground="white",command=lambda:verifCode(code,code_e.get()))
    code_but.place(x=150,y=150)
def verifcompte():
    if name_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre nom")
    elif prename_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre prenom")
    elif mail_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre adresse E-mail")
    elif mdp_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez remplir votre mot de passe")
    elif mdpConfirm_e.get()=="":
         warn_supp=messagebox.showerror("ERREUR","Veuillez confirmer votre mot de passe")         
    elif mdp_e.get() != mdpConfirm_e.get():
        warn_supp=messagebox.showerror("ERREUR","La confirmation du mot de passe a échoué") 
    else :
        verifMail()
def verifCode(code:str,codeEntrer:str):
    print(code)
    print(codeEntrer)
    if code != codeEntrer:
        warn_supp=messagebox.showerror("ERREUR","Code Invalide")
    else:
        code_info =messagebox.showinfo("Information","Compte Validé.")
        compte(name_e.get(),prename_e.get(),mail_e.get(),mdp_e.get())
        fenetre_creCompte.destroy()
        fenetre_mail.destroy()
        
        
        
        
        
        
        
fenetre_base=Tk()
fenetre_base.resizable(width=False, height=False)

pixelVirtual =PhotoImage(width=1, height=1)
fenetre_base.title("Page de connexion")
fenetre_base.geometry("900x600")
fenetre_base.config(background="#42424D")
back =Image.open("back4.png")
background_image=ImageTk.PhotoImage(back)
imgback = Label(fenetre_base,image=background_image)
imgback.place(x=0,y=0)

menuu = Canvas(fenetre_base, width=460, height=350,bg="white")
menuu.place(x=220,y=100)
menuu.create_text(230,30,text="Se connecter",font=("Courrier",25))

menuu.create_text(133,100,text="Identifiants :",font=("Courrier",15))
identifiants = Entry(fenetre_base,bg="#4B4B57",font=("Courrier",20),fg="white")
identifiants.place(x=300,y=210)

menuu.create_text(145,190,text="Mot de passe :",font=("Courrier",15))
MDP = Entry(fenetre_base,bg="#4B4B57",font=("Courrier",20),fg="white",show="*")
MDP.place(x=300,y=300)

login_but=Button(menuu,font=("Courrier",10),fg="BLACK",bg='red',text="Se connecter",width=20,height=1,activebackground="black",activeforeground="white",command=lambda:connexion())
login_but.place(x=140,y=270)

menuu.create_text(230,330,text="pas de compte ? créer un compte",font=("Courrier",10),activefill="blue")
fenetre_base.bind("<Button-1>",clique)
fenetre_base.mainloop()